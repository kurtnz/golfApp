// App
// ----------------------------------------------

var GolfApp = new Marionette.Application();